delete from Customer;
insert into Customer (id, name, surname, age, city, address)
values (NEXT VALUE FOR customer_seq, 'Mario', 'Rossi', 24, 'Lugano', 'via Roma 3'),
       (NEXT VALUE FOR customer_seq, 'Guido', 'Bianchi', 34, 'Roma', 'via Torino 4'),
       (NEXT VALUE FOR customer_seq, 'Gino', 'Verdi', 57, 'Parigi', 'via Milano 55');