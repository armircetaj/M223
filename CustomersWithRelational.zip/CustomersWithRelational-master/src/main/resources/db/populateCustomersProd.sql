delete from Customer;
insert into Customer (id, name, surname, age, city, address)
values (100, 'Pascal', 'Poncini', 24, 'Lugano', 'via Roma 3'),
       (101, 'Maurizio', 'Di Florio', 34, 'Roma', 'via Torino 4'),
       (102, 'Luca', 'Muggiasca', 57, 'Parigi', 'via Milano 55');