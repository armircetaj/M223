package ch.samt.petstore.service;

import ch.samt.petstore.model.Service;
import ch.samt.petstore.repository.ServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@org.springframework.stereotype.Service
public class ServiceService {

    private final ServiceRepository serviceRepository;

    @Autowired
    public ServiceService(ServiceRepository serviceRepository) {
        this.serviceRepository = serviceRepository;
    }

    public List<Service> getAllActiveServices() {
        return serviceRepository.findByDeletedFalse();
    }

    public Service getServiceById(Long id) {
        return serviceRepository.findById(id).orElseThrow();
    }

    public Service saveService(Service service) {
        return serviceRepository.save(service);
    }

    public void deleteService(Long id) {
        Service service = serviceRepository.findById(id).orElseThrow();
        service.setDeleted(true);
        serviceRepository.save(service);
    }

}
