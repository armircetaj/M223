package ch.samt.petstore.controller;

import ch.samt.petstore.model.Service;
import ch.samt.petstore.service.PetService;
import ch.samt.petstore.service.ServiceService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ServiceController {

    private final ServiceService serviceService;
    private final PetService petService;

    @Autowired
    public ServiceController(ServiceService serviceService, PetService petService) {
        this.serviceService = serviceService;
        this.petService = petService;
    }

    @GetMapping("/services")
    public String listServices(Model model) {
        model.addAttribute("services", serviceService.getAllActiveServices());
        return "services/list";
    }

    @GetMapping("/add-service")
    public String showAddServiceForm(Model model) {
        model.addAttribute("service", new Service());
        model.addAttribute("allPets", petService.getAllPets());
        return "services/add";
    }

    @PostMapping("/add-service")
    public String addService(@Valid @ModelAttribute("service") Service service, Errors errors, Model model) {
        if (errors.hasErrors()) {
            model.addAttribute("allPets", petService.getAllPets());
            return "services/add";
        }
        serviceService.saveService(service);
        return "redirect:/services";
    }

    @GetMapping("/edit-service/{id}")
    public String showEditServiceForm(@PathVariable Long id, Model model) {
        Service service = serviceService.getServiceById(id);
        model.addAttribute("service", service);
        model.addAttribute("allPets", petService.getAllPets());
        return "services/add";
    }

    @PostMapping("/edit-service/{id}")
    public String editService(@PathVariable Long id, @Valid Service service, Errors errors, Model model) {
        if (errors.hasErrors()) {
            model.addAttribute("service", service);
            model.addAttribute("allPets", petService.getAllPets());
            return "services/add";
        }
        service.setId(id);
        serviceService.saveService(service);
        return "redirect:/services";
    }

    @GetMapping("/delete-service/{id}")
    public String deleteService(@PathVariable Long id) {
        serviceService.deleteService(id);
        return "redirect:/services";
    }

}
