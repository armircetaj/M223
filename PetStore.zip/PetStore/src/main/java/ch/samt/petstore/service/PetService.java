package ch.samt.petstore.service;

import ch.samt.petstore.model.Pet;
import ch.samt.petstore.repository.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PetService {

    private final PetRepository petRepository;

    @Autowired
    public PetService(PetRepository petRepository) {
        this.petRepository = petRepository;
    }

    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }


    public Pet savePet(Pet pet) {
        return petRepository.save(pet);
    }

}
