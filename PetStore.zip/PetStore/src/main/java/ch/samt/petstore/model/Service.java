package ch.samt.petstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
public class Service {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "service_seq")
    @SequenceGenerator(name = "service_seq", allocationSize = 1)
    private Long id;

    @NotNull(message = "La data del servizio è obbligatoria")
    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private LocalDate serviceDate;

    @NotBlank(message = "Il tipo di servizio è obbligatorio")
    private String serviceType;

    private String description;

    @NotNull(message = "Il prezzo è obbligatorio")
    private Double price;

    private boolean deleted = false;

    @ManyToMany
    @JoinTable(
            name = "service_pet",
            joinColumns = @JoinColumn(name = "service_id"),
            inverseJoinColumns = @JoinColumn(name = "pet_id"))
    @NotEmpty(message = "Scegli almeno un animale")
    private List<Pet> pets = new ArrayList<>();
}