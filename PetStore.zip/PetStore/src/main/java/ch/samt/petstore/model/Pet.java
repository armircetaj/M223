package ch.samt.petstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Pet {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pet_seq")
    @SequenceGenerator(name = "pet_seq", allocationSize = 1)
    private Long id;

    @NotBlank(message = "Il nome è obbligatorio")
    private String name;

    @NotBlank(message = "La specie è obbligatoria")
    private String species;

    @NotBlank(message = "La razza è obbligatoria")
    private String breed;

    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private LocalDate birthDate;

    @NotBlank(message = "Microchip obbligatorio")
    @Size(min = 4, message = " Almeno 4 caratteri")
    private String microchip;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    @NotNull(message = "Scegli il proprietario")
    private Customer customer;

    @ManyToMany(mappedBy = "pets")
    private List<Service> services = new ArrayList<>();
}
