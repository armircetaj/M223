package ch.samt.petstore.controller;

import ch.samt.petstore.model.Pet;
import ch.samt.petstore.service.CustomerService;
import ch.samt.petstore.service.PetService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PetController {

    private final PetService petService;
    private final CustomerService customerService;

    @Autowired
    public PetController(CustomerService customerService, PetService petService) {
        this.customerService = customerService;
        this.petService = petService;
    }

    @GetMapping("/pets")
    public String listPets(Model model) {
        model.addAttribute("pets", petService.getAllPets());
        return "pets/list";
    }

    @GetMapping("/add-pet")
    public String showAddPetForm(Model model) {
        model.addAttribute("pet", new Pet());
        model.addAttribute("customers", customerService.getAllCustomers());
        return "pets/add";
    }

    @PostMapping("/add-pet")
    public String addPet(@Valid @ModelAttribute("pet") Pet pet, Errors errors, Model model) {
        if (errors.hasErrors()) {
            model.addAttribute("customers", customerService.getAllCustomers());
            return "pets/add";
        }
        petService.savePet(pet);
        return "redirect:/pets";
    }
}
