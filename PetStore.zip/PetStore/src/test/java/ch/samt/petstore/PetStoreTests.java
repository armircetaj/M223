package ch.samt.petstore;

import ch.samt.petstore.model.Customer;
import ch.samt.petstore.model.Pet;
import ch.samt.petstore.model.Service;
import ch.samt.petstore.repository.CustomerRepository;
import ch.samt.petstore.repository.PetRepository;
import ch.samt.petstore.repository.ServiceRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
public class PetStoreTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PetRepository petRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    @BeforeEach
    public void setup() {
        serviceRepository.deleteAll();
        petRepository.deleteAll();
        customerRepository.deleteAll();
    }

    @Test
    public void testAddAndListCustomer() throws Exception {
        mockMvc.perform(post("/add-customer")
                        .param("firstName", "Mario")
                        .param("lastName", "Rossi")
                        .param("customerCode", "ABC12")
                        .param("email", "mario@example.com"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customers"));

        mockMvc.perform(get("/customers"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Mario")))
                .andExpect(content().string(containsString("Rossi")))
                .andExpect(content().string(containsString("ABC12")));
    }

    @Test
    public void testCustomerCodeValidation() throws Exception {
        // Too short
        mockMvc.perform(post("/add-customer")
                        .param("firstName", "Mario")
                        .param("lastName", "Rossi")
                        .param("customerCode", "123"))
                .andExpect(status().isOk())
                .andExpect(view().name("customers/add"))
                .andExpect(model().hasErrors());

        // Too long
        mockMvc.perform(post("/add-customer")
                        .param("firstName", "Mario")
                        .param("lastName", "Rossi")
                        .param("customerCode", "123456"))
                .andExpect(status().isOk())
                .andExpect(view().name("customers/add"))
                .andExpect(model().hasErrors());
    }

    @Test
    public void testAddAndListPet() throws Exception {
        Customer customer = new Customer();
        customer.setFirstName("Luigi");
        customer.setLastName("Verdi");
        customer.setCustomerCode("XYZ78");
        customer = customerRepository.save(customer);

        mockMvc.perform(post("/add-pet")
                        .param("customer", customer.getId().toString())
                        .param("name", "Fido")
                        .param("species", "Cane")
                        .param("microchip", "1234")
                        .param("breed", "Pastore Tedesco"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/pets"));

        mockMvc.perform(get("/pets"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Fido")))
                .andExpect(content().string(containsString("Cane")))
                .andExpect(content().string(containsString("Luigi Verdi")));
    }

    @Test
    public void testAddServiceAndSoftDelete() throws Exception {
        Customer anna = new Customer();
        anna.setFirstName("Anna");
        anna.setLastName("Bianchi");
        anna.setCustomerCode("ANN01");
        anna = customerRepository.save(anna);

        Pet pet = new Pet(null,"Luna","Gatto","Siamese", LocalDate.of(2026, 5, 23), "2233",anna,null);
        pet = petRepository.save(pet);

        mockMvc.perform(post("/add-service")
                        .param("customer", anna.getId().toString())
                        .param("pets", pet.getId().toString())
                        .param("serviceType", "toelettatura")
                        .param("serviceDate", LocalDate.now().toString())
                        .param("price", "50.0")
                        .param("description", "Taglio pelo"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/services"));

        // Verify it exists in list
        mockMvc.perform(get("/services"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("toelettatura")))
                .andExpect(content().string(containsString("Luna")));

        Service service = serviceRepository.findAll().get(0);
        assertFalse(service.isDeleted());

        // Test soft delete
        mockMvc.perform(get("/delete-service/" + service.getId()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/services"));

        // Should not be in the list anymore
        mockMvc.perform(get("/services"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("services", hasSize(0)));

        // But still in database
        Service deletedService = serviceRepository.findById(service.getId()).orElseThrow();
        assertTrue(deletedService.isDeleted());
    }

    @Test
    public void testEditService() throws Exception {
        Customer customer = new Customer();
        customer.setFirstName("Piero");
        customer.setLastName("Neri");
        customer.setCustomerCode("PR001");
        customer = customerRepository.save(customer);

        Pet pet = new Pet(null,"Rex","Cane","Labrador", null, "2233",null,null);
        pet.setCustomer(customer);
        pet = petRepository.save(pet);

        Service service = new Service();
        service.getPets().add(pet);
        service.setServiceType("veterinario");
        service.setServiceDate(LocalDate.now());
        service.setPrice(100.0);
        service = serviceRepository.save(service);

        mockMvc.perform(post("/edit-service/" + service.getId())
                        .param("customer", customer.getId().toString())
                        .param("pets", pet.getId().toString())
                        .param("serviceType", "addestramento")
                        .param("serviceDate", LocalDate.now().toString())
                        .param("price", "150.0")
                        .param("description", "Corso base"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/services"));

        Service updatedService = serviceRepository.findById(service.getId()).orElseThrow();
        assertEquals("addestramento", updatedService.getServiceType());
        assertEquals(150.0, updatedService.getPrice());
    }
}
